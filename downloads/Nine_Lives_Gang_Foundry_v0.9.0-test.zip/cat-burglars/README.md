# Nine Lives Gang for Foundry VTT, version 0.9.0-test

This is a test build, not a release.

## Install by hand

1. Unzip this file into Foundry's `Data/systems` folder, so you get `Data/systems/cat-burglars/system.json`.
2. Restart Foundry.
3. Pick Nine Lives Gang when creating a world.

## Credits

- Created by: Richard Moore
- Game design & writing: Richard Moore
- Typefaces: Rubik Spray Paint, Saira Stencil One, Fraunces, Alegreya and Alegreya Sans, used under the SIL Open Font License 1.1
- Play it online: Nine Lives Gang for Foundry Virtual Tabletop, coming soon

© 2026 Richard Moore. All rights reserved.
