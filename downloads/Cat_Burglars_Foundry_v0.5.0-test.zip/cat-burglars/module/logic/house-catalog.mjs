/**
 * CAT BURGLARS — the five ready-to-run houses (pure data + lookups)
 * --------------------------------------------------------------------
 * COPIED from sim/houses.mjs (core rules v0.8, simulator package P10), which the
 * rulebook house chapters (Ch 14–18, book/tools/house-pages.mjs) are generated
 * from. module/ never imports from sim/: this is a copy, and
 * test/parity.test.mjs fails if the two drift apart. Change sim/houses.mjs (and
 * re-run the book generator) first, then copy the change here.
 *
 * Each house: rooms (temptations; every room has hiding spots unless it says
 * `hide: false`), ways between rooms (size; closed doors with how to open them),
 * entrances (room, size, approach options, climb), humans (Attention, d6
 * routine), pets, the Den, and the prize with its Prize Clock script.
 * Approach options are [approach, Difficulty, ...knack tags].
 * A routine is six results for d6 1–6: "stay", a room key, or (pets) "sniff".
 * `map` places the rooms for the printed floor plans; the Robbery Tracker uses
 * it to lay the rooms out the same way.
 */

const climb = [["sneaky", 1, "climb"], ["savage", 1, "climb"]];
const hardClimb = [["sneaky", 2, "climb"], ["savage", 2, "climb"]];
const door = [["streetwise", 1, "open"], ["savage", 2]];
const stiffDoor = [["streetwise", 2, "open"], ["savage", 2]];
const wrapped = [["streetwise", 1, "open"], ["savage", 1]];   // foil, cling film, a cake cover (tearing it isn't fighting)
const bag = [["streetwise", 1, "open"], ["sneaky", 1]];                // rummage in a shopping bag

export const HOUSES = [
  {
    key: "number-12", name: "The Chicken at Number 12", label: "easy", patience: 4,
    map: {
      floors: [{ name: "Ground floor", rooms: { kitchen: [0, 0, 4, 2], utility: [4, 0, 2, 2], living: [0, 2, 2, 3], hall: [2, 2, 2, 3], loo: [4, 2, 2, 3] } }],
      entrances: { front: "bottom", flap: "top", window: "top" },
    },
    rooms: {
      hall: { name: "Hall", tempt: ["curious"] },
      living: { name: "Living room", tempt: ["boxSitter", "lapCat", "knocker"] },
      kitchen: { name: "Kitchen", tempt: ["foodie", "knocker", "climber"] },
      utility: { name: "Utility room", tempt: ["hunter", "curious"] },
      loo: { name: "Downstairs loo", tempt: [] },
    },
    ways: [["hall", "living", "big"], ["hall", "kitchen", "big"], ["kitchen", "utility", "big", door], ["hall", "loo", "big"]],
    entrances: [
      { key: "front", name: "Front door (behind Mr Pell)", room: "hall", size: "big", rounds: [1], one: true, letOut: true, opts: [["sneaky", 2], ["sweet", 0, "charm"]] },
      { key: "flap", name: "Cat flap in the back door", room: "utility", size: "normal", opts: [], noisy: true },
      { key: "window", name: "Open kitchen window (up the bins)", room: "kitchen", size: "normal", climb: true, opts: climb },
    ],
    den: "loo",
    humans: [
      { key: "pell", name: "Mr Pell", kind: "grownup", attention: 1, start: "hall",
        routine: ["stay", "stay", "kitchen", "kitchen", "living", "living"] },
    ],
    pets: [{ key: "pudding", name: "Pudding", kind: "dog", rating: 2, soft: true, start: "kitchen", asleep: false,
      roam: ["kitchen", "hall", "living", "utility"], routine: ["stay", "stay", "living", "kitchen", "hall", "sniff"] }],
    prize: {
      kind: "delicious", name: "rotisserie chicken", size: "medium", perCat: 1, plus: 1,
      script: [{ round: 2, room: "kitchen", steps: [climb, wrapped], by: "pell" }], goneAt: 10,
    },
  },
  {
    key: "okafor-box", name: "The Okafors' Big Box", label: "standard", patience: 7,
    map: {
      floors: [
        { name: "Ground floor", rooms: { kitchen: [0, 0, 5, 2], garage: [5, 0, 3, 5], living: [0, 2, 3, 3], hall: [3, 2, 2, 3] } },
        { name: "Upstairs", rooms: { bathroom: [0, 0, 2, 3], landing: [2, 0, 2, 3], kidsroom: [4, 0, 3, 3] } },
      ],
      entrances: { front: "bottom", dogdoor: "top", bathwin: "left", garage: "right" },
    },
    rooms: {
      hall: { name: "Hall", tempt: ["boxSitter"] },
      living: { name: "Living room", tempt: ["lapCat", "hunter", "knocker"] },
      kitchen: { name: "Kitchen", tempt: ["foodie", "curious"] },
      garage: { name: "Garage", tempt: ["hunter", "climber"] },
      landing: { name: "Landing", tempt: ["climber"] },
      bathroom: { name: "Bathroom", tempt: [] },
      kidsroom: { name: "Tayo's room", tempt: ["boxSitter"] },
    },
    ways: [["hall", "living", "big"], ["hall", "kitchen", "big"], ["kitchen", "garage", "big"],
      ["hall", "landing", "normal"], ["landing", "bathroom", "big"], ["landing", "kidsroom", "big"]],
    entrances: [
      { key: "front", name: "Front door (behind Mrs Okafor)", room: "hall", size: "big", rounds: [1], one: true, letOut: true, opts: [["sneaky", 2], ["sweet", 0, "charm"]] },
      { key: "dogdoor", name: "Dog door", room: "kitchen", size: "normal", opts: [] },
      { key: "bathwin", name: "Bathroom window (over the shed roof)", room: "bathroom", size: "normal", climb: true, opts: climb },
      { key: "garage", name: "Garage side door, ajar", room: "garage", size: "big", opts: [] },
    ],
    den: "kidsroom",
    humans: [
      { key: "mum", name: "Mrs Okafor", kind: "grownup", attention: 1, start: "hall",
        routine: ["stay", "stay", "stay", "kitchen", "living", "living"] },
      { key: "tayo", name: "Tayo", kind: "kid", attention: 1, start: "living",
        routine: ["stay", "stay", "kidsroom", "kidsroom", "living", "kitchen"] },
    ],
    pets: [{ key: "noodle", name: "Noodle", kind: "dog", rating: 2, soft: true, start: "kitchen", asleep: true,
      roam: ["kitchen", "hall", "living", "garage"], routine: ["stay", "stay", "hall", "garage", "living", "sniff"] }],
    prize: {
      kind: "box", name: "big delivery box", size: "large",
      script: [{ round: 1, room: "hall", steps: [], by: "mum" }, { round: 5, room: "living", steps: [], by: "mum" }], goneAt: 13,
    },
  },
  {
    key: "wendell-mouse", name: "Grandpa Wendell's Catnip Mouse", label: "standard", patience: 7,
    map: {
      floors: [
        { name: "Ground floor", rooms: { kitchen: [0, 0, 5, 2], living: [0, 2, 3, 3], hall: [3, 2, 2, 3] } },
        { name: "Upstairs", rooms: { bedroom: [0, 0, 2, 3], landing: [2, 0, 2, 3], bathroom: [4, 0, 2, 3] } },
        { name: "Cellar", rooms: { cellar: [0, 0, 4, 2] } },
      ],
      entrances: { front: "bottom", flap: "top", cellarwin: "top", bedwin: "left" },
    },
    rooms: {
      hall: { name: "Hall", tempt: ["curious"] },
      living: { name: "Living room", tempt: ["hunter", "lapCat", "boxSitter"] },
      kitchen: { name: "Kitchen", tempt: ["foodie", "knocker"] },
      cellar: { name: "Cellar", tempt: ["hunter", "curious"] },
      landing: { name: "Landing", tempt: [] },
      bedroom: { name: "Spare bedroom", tempt: ["climber", "boxSitter"] },
      bathroom: { name: "Bathroom", tempt: ["boxSitter"] },
    },
    ways: [["hall", "living", "big"], ["hall", "kitchen", "big"], ["kitchen", "cellar", "normal", door],
      ["hall", "landing", "normal"], ["landing", "bedroom", "big"], ["landing", "bathroom", "big"]],
    entrances: [
      { key: "front", name: "Front door (behind Grandpa)", room: "hall", size: "big", rounds: [1], one: true, letOut: true, opts: [["sneaky", 2], ["sweet", 0, "charm"]] },
      { key: "flap", name: "Pom-Pom's microchip cat flap (jam it open)", room: "kitchen", size: "normal", opts: [["streetwise", 1, "open"]], jam: true, noisy: true },
      { key: "cellarwin", name: "Cracked cellar window", room: "cellar", size: "tight", opts: [] },
      { key: "bedwin", name: "Bedroom window (up the drainpipe)", room: "bedroom", size: "normal", climb: true, opts: hardClimb },
    ],
    den: "bathroom",
    humans: [
      { key: "wendell", name: "Grandpa Wendell", kind: "grandparent", attention: 0, start: "hall",
        routine: ["stay", "stay", "hall", "hall", "living", "kitchen"] },
      { key: "june", name: "June", kind: "grownup", attention: 1, start: "kitchen",
        routine: ["stay", "stay", "stay", "living", "hall", "landing"] },
    ],
    pets: [
      { key: "pompom", name: "Pom-Pom", kind: "housecat", rating: 2, soft: true, start: "living" },
      { key: "roomba", name: "The robot vacuum", kind: "vacuum", start: "living", roam: ["living", "hall", "kitchen"] },
    ],
    prize: {
      kind: "fun", name: "catnip mouse", size: "small",
      script: [{ round: 1, room: "hall", steps: [bag], by: "wendell" }, { round: 4, room: "living", steps: [], by: "wendell" }], goneAt: 9,
    },
  },
  {
    key: "birthday-cake", name: "The Birthday Cake", label: "hard", patience: 6,
    map: {
      floors: [{ name: "Ground floor", rooms: { dining: [0, 0, 3, 3], kitchen: [3, 0, 3, 2], utility: [6, 0, 2, 2], loo: [0, 3, 3, 2], hall: [3, 2, 2, 3], living: [5, 2, 3, 3] } }],
      entrances: { front: "bottom", patio: "left", utilwin: "top" },
    },
    rooms: {
      hall: { name: "Hall", tempt: ["curious", "boxSitter"] },
      kitchen: { name: "Kitchen", tempt: ["foodie", "knocker"] },
      dining: { name: "Dining room", tempt: ["hunter", "climber"] },
      living: { name: "Living room", tempt: ["hunter", "boxSitter", "lapCat"] },
      utility: { name: "Utility room", tempt: ["curious"] },
      loo: { name: "Downstairs loo", tempt: [] },
    },
    ways: [["hall", "kitchen", "big"], ["hall", "living", "big"], ["hall", "dining", "big"], ["kitchen", "dining", "big"],
      ["kitchen", "utility", "big"], ["hall", "loo", "big"]],
    entrances: [
      { key: "front", name: "Front door (guests arriving)", room: "hall", size: "big", rounds: [1, 2], one: true, letOut: true, opts: [["sneaky", 2], ["sweet", 0, "charm"]] },
      { key: "patio", name: "Patio door, ajar", room: "dining", size: "big", opts: [] },
      { key: "utilwin", name: "Utility window (up the water butt)", room: "utility", size: "normal", climb: true, opts: climb },
    ],
    den: "loo",
    humans: [
      { key: "dad", name: "Dad", kind: "grownup", attention: 1, start: "kitchen",
        routine: ["stay", "kitchen", "kitchen", "dining", "dining", "living"] },
      { key: "rosalind", name: "Aunt Rosalind", kind: "grownup", attention: 2, start: "dining",
        routine: ["stay", "stay", "stay", "stay", "kitchen", "living"] },
      { key: "mia", name: "Mia", kind: "kid", attention: 1, start: "living",
        routine: ["stay", "stay", "dining", "hall", "kitchen", "living"] },
      { key: "leo", name: "Leo", kind: "kid", attention: 1, start: "living",
        routine: ["stay", "stay", "dining", "dining", "hall", "living"] },
    ],
    pets: [{ key: "captain", name: "Captain the parrot", kind: "parrot", start: "dining" }],
    prize: {
      kind: "delicious", name: "birthday cake", size: "medium", perCat: 2, plus: 0, haulDiff: 1, // it wobbles: hauling it is Tricky
      script: [{ round: 1, room: "kitchen", steps: [climb, wrapped], by: "dad" }, { round: 5, room: "dining", steps: [climb], by: "dad" }], goneAt: 8,
    },
  },
  {
    key: "marchetti-salmon", name: "Chef Marchetti's Salmon", label: "hard", patience: 6,
    map: {
      floors: [
        { name: "Ground floor", rooms: { kitchen: [0, 0, 4, 2], utility: [4, 0, 3, 2], living: [0, 2, 3, 3], hall: [3, 2, 4, 3] } },
        { name: "Upstairs", rooms: { bedroom: [0, 0, 2, 3], landing: [2, 0, 2, 3], study: [4, 0, 2, 3] } },
      ],
      entrances: { front: "bottom", dogdoor: "top", balcony: "left", skylight: "roof" },
    },
    rooms: {
      hall: { name: "Hall", tempt: [] },
      kitchen: { name: "Kitchen", tempt: ["foodie", "knocker", "hunter"] },
      living: { name: "Living room", tempt: ["lapCat", "boxSitter"] },
      utility: { name: "Utility room", tempt: ["foodie"] },
      landing: { name: "Landing", tempt: [] },
      bedroom: { name: "Bedroom", tempt: ["boxSitter"] },
      study: { name: "Study", tempt: ["climber", "curious"] },
    },
    ways: [["hall", "kitchen", "big"], ["hall", "living", "big"], ["kitchen", "utility", "big", stiffDoor],
      ["hall", "landing", "normal"], ["landing", "bedroom", "big"], ["landing", "study", "big"]],
    entrances: [
      { key: "front", name: "Front door (behind Sam)", room: "hall", size: "big", rounds: [1], one: true, letOut: true, opts: [["sneaky", 2], ["sweet", 0, "charm"]] },
      { key: "dogdoor", name: "Brutus's dog door (a heavy flap)", room: "utility", size: "normal", opts: [], noisy: true },
      { key: "balcony", name: "Balcony door (up the tree)", room: "bedroom", size: "normal", climb: true, opts: hardClimb },
      { key: "skylight", name: "Skylight, propped open", room: "landing", size: "tight", climb: true, opts: climb },
    ],
    den: "study",
    humans: [
      { key: "chef", name: "Chef Marchetti", kind: "grownup", attention: 2, start: "kitchen", busy: true,
        routine: ["kitchen", "kitchen", "kitchen", "kitchen", "kitchen", "hall"] },
      { key: "sam", name: "Sam", kind: "grownup", attention: 1, start: "hall",
        routine: ["stay", "stay", "living", "living", "kitchen", "study"] },
    ],
    pets: [
      { key: "brutus", name: "Brutus", kind: "dog", rating: 3, soft: false, start: "utility", asleep: false,
        roam: ["utility", "kitchen", "hall", "living"], routine: ["stay", "kitchen", "hall", "living", "sniff", "sniff"] },
      { key: "roomba", name: "The robot vacuum", kind: "vacuum", start: "living", roam: ["living", "hall", "kitchen"] },
    ],
    prize: {
      kind: "delicious", name: "whole salmon", size: "medium", perCat: 1, plus: 2,
      script: [{ round: 1, room: "kitchen", steps: [climb, wrapped], by: "chef" }], goneAt: 8,
    },
  },
];

export const houseByKey = Object.fromEntries(HOUSES.map(h => [h.key, h]));

/** Ch 10 traits from a catalog human (kind and flags). */
export function humanTraits(h) {
  const t = [];
  if (h.kind === "kid") t.push("kid");
  if (h.kind === "grandparent") t.push("dozes");
  if (h.kind === "teen") t.push("headphones");
  if (h.busy) t.push("busy");
  for (const x of h.traits ?? []) if (!t.includes(x)) t.push(x);
  return t;
}

/**
 * Find a house by catalog key, by name, or by a house journal's flag
 * (flags["cat-burglars"].house). Returns the catalog entry or null.
 */
export function findHouse(ref) {
  if (!ref) return null;
  if (typeof ref === "object") {
    if (ref.rooms && ref.prize) return ref;                         // already a house
    const flagged = ref.flags?.["cat-burglars"]?.house;
    if (flagged) return findHouse(flagged);
    return findHouse(ref.name);
  }
  const s = String(ref).trim();
  return houseByKey[s] ?? HOUSES.find(h => h.name.toLowerCase() === s.toLowerCase()) ?? null;
}

/** A plain-text one-line summary of an approach option list: "Sneaky or Savage, Tricky". */
export function optionsText(opts) {
  if (!opts?.length) return "no roll";
  const label = a => a[0].toUpperCase() + a.slice(1);
  const diff = d => (d === 0 ? "" : d === 1 ? "Tricky" : "Hard");
  const groups = new Map();
  for (const [a, d] of opts) { const k = diff(d); (groups.get(k) ?? groups.set(k, []).get(k)).push(label(a)); }
  return [...groups].map(([d, as]) => as.join(" or ") + (d ? ", " + d : "")).join("; or ");
}
